package com.blankj.plugin

class ReadmeExtension {

    File readmeFile
    File readmeCnFile

}
