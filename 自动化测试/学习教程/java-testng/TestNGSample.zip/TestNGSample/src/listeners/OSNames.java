package listeners;
public class OSNames {
	public static final String OS_WINDOWS = "OS_Windows";
	public static final String OS_LINUX = "OS_Linux";
	public static final String OS_UNKNOWN = "OS_Unknown";
}
