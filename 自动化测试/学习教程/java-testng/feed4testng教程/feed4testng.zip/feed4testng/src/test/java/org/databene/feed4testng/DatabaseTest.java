/*
 * (c) Copyright 2011 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License (GPL).
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.feed4testng;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.sql.Connection;
import java.sql.SQLException;

import org.databene.benerator.anno.Database;
import org.databene.benerator.anno.Source;
import org.databene.commons.ConnectFailedException;
import org.databene.jdbacl.DBUtil;
import org.databene.jdbacl.hsql.HSQLUtil;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests handling of the {@link Database} annotation.<br/>
 * <br/>
 * Created: 31.05.2011 12:30:07
 * 
 * @since 0.6.6
 * @author Volker Bergmann
 */
@Database(id = "db", url = "jdbc:hsqldb:mem:f4tdb", driver = "org.hsqldb.jdbcDriver", user = "sa", schema = "public")
public class DatabaseTest extends FeedTest {

	@BeforeClass
	public void setUp() throws ConnectFailedException, SQLException {
		Connection connection = HSQLUtil.connectInMemoryDB("f4tdb");
		DBUtil.executeUpdate("create table dbt_person ( id int, name varchar(20))", connection);
		DBUtil.executeUpdate("insert into dbt_person values (1, 'Alice')", connection);
		DBUtil.executeUpdate("insert into dbt_person values (2, 'Bob')", connection);
		DBUtil.executeUpdate("insert into dbt_person values (3, 'Charly')", connection);
	}

	@Test(dataProvider = "feeder")
	@Source(id = "db", selector = "select name from dbt_person")
	public void test1(String name) {
		System.out.println("DatabaseTest #1: " + name);
		// TODO v0.6.7 verify invocation count
	}

	@Test(dataProvider = "feeder")
	@Source(id = "db", selector = "select id, name from dbt_person")
	public void test2(int id, String name) {
		System.out.println("DatabaseTest #2: " + id + ", " + name);
		assertTrue(id >= 1 && id <= 3);
		switch (id) {
		case 1:
			assertEquals("Alice", name);
			break;
		case 2:
			assertEquals("Bob", name);
			break;
		case 3:
			assertEquals("Charly", name);
			break;
		}
		// TODO v0.6.7 verify invocation count
	}

}
