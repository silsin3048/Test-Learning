/*
 * (c) Copyright 2010-2011 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License (GPL).
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.feed4testng;

import java.util.Arrays;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.databene.benerator.anno.Descriptor;
import org.databene.benerator.anno.Distribution;
import org.databene.benerator.anno.Granularity;
import org.databene.benerator.anno.InvocationCount;
import org.databene.benerator.anno.NullQuota;
import org.databene.benerator.anno.Source;
import org.databene.benerator.anno.Values;
import org.testng.annotations.Test;

/**
 * Tests the benerator annotations in Feed4TestNG.<br/><br/>
 * Created: 09.05.2010 07:31:11
 * @since 0.6.2
 * @author Volker Bergmann
 */
public class BeneratorAnnoTestNGTest extends FeedTest {

	static final Object[][] PERSONS = {
		{"Alice", 23},
		{"Bob",   34}
	};
	
	
	
	// tests -----------------------------------------------------------------------------------------------------------
	

	
	static int testInvocationCount = 0;
	
	@Test(dataProvider = "feeder")
	@InvocationCount(5)
	public void testInvocationCount(String name) {
		System.out.println("testInvocationCount --> " + name);
		testInvocationCount++;
		assert (testInvocationCount <= 5);
		// TODO v0.6.7 verify invocation count
	}
	
	
		
	@Test(dataProvider = "feeder")
	@Descriptor
	public void testDescriptorBased(String name, int age) {
		System.out.println("testDescriptorBased --> " + name + ", " + age);
		assert ("Alice".equals(name) || "Bob".equals(name));
		assert (age == 23 || age == 34);
		// TODO v0.6.7 verify invocation count
	}
	
	
	
	static int methodGeneratorCount = 0;
	
	@Test(dataProvider = "feeder")
	@org.databene.benerator.anno.Generator("org.databene.feed4testng.PGen")
	public void testMethodGenerator(String name, int age) {
		System.out.println("testMethodGenerator --> " + name + ", " + age);
		Object[] expected = PERSONS[methodGeneratorCount];
		Object[] actual = new Object[] { name, age };
		assert Arrays.equals(expected, actual);
		methodGeneratorCount++;
		// TODO v0.6.7 verify invocation count
	}
	
	
	
	static int paramGeneratorCount = 0;
	
	@Test(dataProvider = "feeder")
	@InvocationCount(5)
	public void testParamGenerator(
			@org.databene.benerator.anno.Generator("new org.databene.benerator.sample.ConstantGenerator(28)") 
			int age) {
		System.out.println("testParamGenerator --> " + age);
		assert age == 28;
		paramGeneratorCount++;
		// TODO v0.6.7 verify invocation count
	}
	
	
	
	
	
	
	int testDistributionExpected = 1;
	
	@Test(dataProvider = "feeder")
	public void testDistribution(@Min(1) @Max(6) @Distribution("step") @Granularity(2) int n) {
		System.out.println("testDistribution --> " + n);
		assert n == testDistributionExpected;
		assert n < 6;
		testDistributionExpected += 2;
		// TODO v0.6.7 verify invocation count
	}
	
	
	
	@Test(dataProvider = "feeder")
	@InvocationCount(10)
	public void testNullQuotaOne(@NullQuota(1) String name) {
		assert name == null;
		// TODO v0.6.7 verify invocation count
	}
	

	/* TODO make this work
	@Test(dataProvider = "feeder")
	public void testNullQuotaZero(@NullQuota(0) String name) {
		assert name != null;
		// TODO v0.6.7 verify invocation count
	}
	*/
	
	
	int testNullCount = 0;
	int testNotNullCount = 0;
	
	@Test(dataProvider = "feeder")
	@InvocationCount(50)
	public void testNullQuotaHalf(@NullQuota(0.5) String name) {
		if (name == null)
			testNullCount++;
		else
			testNotNullCount++;
		// TODO v0.6.7 verify invocation count
	}
	
	

	/* TODO v0.6.7 test size distribution
	int expectedSize = 1;
	
	@Test(dataProvider = "feeder")
	public void testSizeDistribution(@Size(min = 1, max = 3) @SizeDistribution("step") String name) {
		System.out.println("testSizeDistribution -> " + name);
		assert name.length() == expectedSize;
		expectedSize++;
	}*/


	
	@Test(dataProvider = "feeder")
	@Source("org/databene/feed4testng/users.csv")
	public void testMethodSource(String name, int age) {
		System.out.println("testMethodSource --> " + name + ", " + age);
		Object[] person = new Object[] { name, age }; 
		assert Arrays.equals(person, PERSONS[0]) || Arrays.equals(person, PERSONS[1]);
		// TODO v0.6.7 verify invocation count
	}
	

	
	@Test(dataProvider = "feeder")
	public void testParamSource(@Source("org/databene/feed4testng/names.csv") String name) {
		System.out.println("testParamSource --> " + name);
		assert "Alice".equals(name) || "Bob".equals(name);
		// TODO v0.6.7 verify invocation count
	}
	

	
	@Test(dataProvider = "feeder")
	@InvocationCount(100)
	public void testValues(@NotNull @Values({ "Alice", "Bob" }) String name, @Values({ "23", "34" }) int age) {
		assert ("Alice".equals(name) || "Bob".equals(name));
		assert (age == 23 || age == 34);
		// TODO v0.6.7 verify invocation count
	}
	
}
