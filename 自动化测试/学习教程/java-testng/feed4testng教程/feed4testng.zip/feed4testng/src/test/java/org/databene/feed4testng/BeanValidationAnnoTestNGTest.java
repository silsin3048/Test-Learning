/*
 * (c) Copyright 2010 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License (GPL).
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.feed4testng;

import java.util.Date;

import javax.validation.constraints.AssertFalse;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.testng.annotations.Test;

/**
 * Tests the support of Bean Validation Annotations in Feed4TestNG.<br/><br/>
 * Created: 09.05.2010 07:16:45
 * @since 0.6.2
 * @author Volker Bergmann
 */
public class BeanValidationAnnoTestNGTest extends FeedTest {

	@Test(dataProvider = "feeder")
	public void testAssertFalse(@AssertFalse boolean b) {
		assert !b;
	}
	
	@Test(dataProvider = "feeder")
	public void testAssertTrue(@AssertTrue boolean b) {
		assert b;
	}
	
	@Test(dataProvider = "feeder")
	public void testDecimalMinMax(@DecimalMin("-2.5") @DecimalMax("3.75") double d) {
		System.out.println("testDecimalMinMax: " + d);
		assert d >= -2.5 && d <= 3.75;
	}
	
	/* TODO v0.6.7 test integer and fraction digits
	@Test(dataProvider = "feeder")
	@InvocationCount(5)
	public void testDigits(@Digits(integer = 1, fraction = 1) double d) {
		System.out.println("testDigits: " + d);
	}*/
	
	@Test(dataProvider = "feeder")
	public void testFuture(@Future @NotNull Date date) {
		Date now = new Date();
		System.out.println("testFuture: " + date);
		assert !date.before(now);
	}
	
	@Test(dataProvider = "feeder")
	public void testMinMax(@Min(-2) @Max(3) int i) {
		System.out.println("testMinMax: " + i);
		assert i >= -2 && i <= 3;
	}
	
	@Test(dataProvider = "feeder")
	public void testNotNull(@NotNull String s) {
		System.out.println("testNotNull: " + s);
		assert s != null;
	}
	
	@Test(dataProvider = "feeder")
	public void testNull(@Null String s) {
		assert s == null;
	}
	
	@Test(dataProvider = "feeder")
	public void testPast(@Past @NotNull Date date) {
		Date now = new Date();
		System.out.println("testPast: " + date);
		assert !now.before(date);
	}
	
	@Test(dataProvider = "feeder")
	public void testPattern(@NotNull @javax.validation.constraints.Pattern(regexp = "[A-Z][a-z]{3,8}") String name) {
		System.out.println("testPattern: " + name);
		assert java.util.regex.Pattern.matches("[A-Z][a-z]{3,8}", name);
	}

	@Test(dataProvider = "feeder")
	public void testSize(@NotNull @Size(min = 3, max = 5) String text) {
		System.out.println("text: " + text);
		assert (text.length() >= 3 && text.length() <= 5);
	}

}
