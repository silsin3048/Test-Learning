/*
 * (c) Copyright 2011 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License (GPL).
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.feed4testng;

import org.databene.benerator.anno.Bean;
import org.databene.benerator.anno.InvocationCount;
import org.databene.benerator.anno.Property;
import org.databene.benerator.anno.Source;
import org.databene.benerator.util.UnsafeMethodParamsGenerator;
import org.databene.benerator.wrapper.ProductWrapper;
import org.testng.annotations.Test;

/**
 * Tests handling of {@link Bean}, {@link Property} and {@link Source} annotations
 * for the creation of individual JavaBeans for data import.<br/><br/>
 * Created: 01.07.2011 15:07:43
 * @since 0.6.6
 * @author Volker Bergmann
 */
@Bean(id = "classBean", type = BeanSourceTest.DataIterable.class)
public class BeanSourceTest extends FeedTest {

	
	@Test(dataProvider = "feeder")
	@InvocationCount(7)
	@Source("classBean")
	public void testValues(int i1, int i2, int i3) {
		System.out.println("BeanSourceTest: " + i1 + ", " + i2 + ", " + i3);
		assert (i1 == 1);
		assert (i2 == 2);
		assert (i3 == 3);
	}
	
	
	// helpers ---------------------------------------------------------------------------------------------------------

	public static class DataIterable extends UnsafeMethodParamsGenerator {

		public ProductWrapper<Object[]> generate(ProductWrapper<Object[]> wrapper) {
			return wrapper.wrap(new Object[] { 1, 2, 3 });
		}

	}

}
