/*
 * (c) Copyright 2010-2011 by Volker Bergmann. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is permitted under the terms of the
 * GNU General Public License (GPL).
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED CONDITIONS,
 * REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE
 * HEREBY EXCLUDED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.databene.feed4testng;

import java.lang.reflect.Method;
import java.util.Iterator;

import org.databene.benerator.Generator;
import org.databene.benerator.anno.AnnotationMapper;
import org.databene.benerator.engine.BeneratorContext;
import org.databene.benerator.engine.DefaultBeneratorContext;
import org.databene.benerator.factory.EquivalenceGeneratorFactory;
import org.testng.annotations.DataProvider;

/**
 * Parent class for Feed4TestNG tests.<br/><br/>
 * Created: 19.04.2010 06:28:43
 * @since 0.6.2
 * @author Volker Bergmann
 */
public abstract class FeedTest {
	
    @DataProvider
	public Iterator<Object[]> feeder(Method testMethod) {
		Class<?> testClass = testMethod.getDeclaringClass();
		EquivalenceGeneratorFactory generatorFactory = new EquivalenceGeneratorFactory();
		AnnotationMapper mapper = new AnnotationMapper(generatorFactory);
		BeneratorContext context = new DefaultBeneratorContext();
		context.setGeneratorFactory(generatorFactory);
		mapper.parseClassAnnotations(testClass.getAnnotations(), context);
		Generator<Object[]> generator = mapper.createAndInitMethodParamsGenerator(testMethod, context);
		return new FeedIterator(generator);
	}
	
}
