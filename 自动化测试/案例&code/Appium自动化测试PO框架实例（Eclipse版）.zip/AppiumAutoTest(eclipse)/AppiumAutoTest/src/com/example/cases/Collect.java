package com.example.cases;

import com.example.base.InitAppium;

/**
 * �ҵ��ղ�case
 * Created by LITP on 2016/9/28.
 */


public class Collect extends InitAppium{






}
