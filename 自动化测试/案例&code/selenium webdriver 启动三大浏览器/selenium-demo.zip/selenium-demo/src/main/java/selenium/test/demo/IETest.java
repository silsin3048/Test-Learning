package selenium.test.demo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

/**
 * 启动chrome
 *
 */
public class IETest {
	@Test
	public void init() {
		System.out.println("start selenium IE");
		// 设置IEdriver路径
		System.setProperty("webdriver.ie.driver",
				System.getProperty("user.dir") + "\\extend\\IEDriverServer-3.4.0.exe");
//      代码关闭IE一些配置
		DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
		dc.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		dc.setCapability("ignoreProtectedModeSettings", true);
		// 初始化IE浏览器实例
		WebDriver driver = new InternetExplorerDriver();
		// 最大化窗口
		driver.manage().window().maximize();
		// 设置隐性等待时间
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		// 打开一个站点
		driver.get("http://www.baidu.com/");
		// 获取当前页面的标题
		System.out.println("当前打开页面的标题是：" + driver.getTitle());
		// 关闭浏览器
		driver.close();
		System.out.println("end selenium IE");
	}
}
