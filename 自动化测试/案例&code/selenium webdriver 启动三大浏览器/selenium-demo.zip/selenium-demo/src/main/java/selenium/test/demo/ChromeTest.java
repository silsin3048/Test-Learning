package selenium.test.demo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

/**
 * 启动chrome
 *
 */
public class ChromeTest {
	@Test
	public void init() {
		System.out.println("start selenium chrome");
		// 设置chrome的安装路径
		System.setProperty("webdriver.chrome.bin",
				"C:\\Users\\Administrator\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe");
		// 设置chromedriver路径
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\extend\\chromedriver-2.40.exe");
		// 初始化Chrome浏览器实例
		WebDriver driver = new ChromeDriver();
		// 最大化窗口
		driver.manage().window().maximize();
		// 设置隐性等待时间
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		// 打开一个站点
		driver.get("http://www.baidu.com/");
		// 获取当前页面的标题
		System.out.println("当前打开页面的标题是：" + driver.getTitle());
		// 关闭浏览器
		driver.close();
		System.out.println("end selenium chrome");
	}
}
